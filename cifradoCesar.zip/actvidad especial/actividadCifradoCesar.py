def cifrar_mensaje(mensaje, clave):
    resultado = ""
    for char in mensaje:
        if char.isalpha():
            
            desplazamiento = (ord(char) - ord('a') + clave) % 26
            resultado += chr(ord('a') + desplazamiento)
        else:
            resultado += char  
    return resultado

def descifrar_mensaje(mensaje, clave):
    return cifrar_mensaje(mensaje, -clave)  

def validar_entrada(mensaje, clave):
    if not all(c.isalpha() or c.isspace() for c in mensaje):
        return False, "El mensaje solo puede contener letras y espacios."
    if not isinstance(clave, int):
        return False, "La clave debe ser un número entero."
    return True, ""

def menu():
    while True:
        print("*** Menú Cifrado César ***")
        print("1. Cifrar un mensaje")
        print("2. Descifrar un mensaje")
        print("3. Salir")
        
        opcion = input("Elige una opción: ")
        
        if opcion == '1':
            mensaje = input("Ingresa el mensaje a cifrar: ")
            clave = input("Ingresa la clave de cifrado: ")
            
            try:
                clave = int(clave)
                es_valido, mensaje_error = validar_entrada(mensaje, clave)
                if es_valido:
                    mensaje_cifrado = cifrar_mensaje(mensaje, clave)
                    print(f"Mensaje cifrado: {mensaje_cifrado}")
                else:
                    print(mensaje_error)
            except ValueError:
                print("Por favor, ingresa un número entero válido como clave.")
        
        elif opcion == '2':
            mensaje = input("Ingresa el mensaje a descifrar: ")
            clave = input("Ingresa la clave de descifrado: ")
            
            try:
                clave = int(clave)
                es_valido, mensaje_error = validar_entrada(mensaje, clave)
                if es_valido:
                    mensaje_descifrado = descifrar_mensaje(mensaje, clave)
                    print(f"Mensaje descifrado: {mensaje_descifrado}")
                else:
                    print(mensaje_error)
            except ValueError:
                print("Por favor, ingresa un número entero válido como clave.")
        
        elif opcion == '3':
            print("Saliendo del programa.")
            break
        
        else:
            print("Opción no válida. Por favor, elige una opción del menú.")

if __name__ == "__main__":
    menu()
